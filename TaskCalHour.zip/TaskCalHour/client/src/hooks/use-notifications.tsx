import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { playNotificationSound } from "@/lib/audio";
import { hapticFeedback } from "@/lib/haptics";
import type { Task } from "@shared/schema";

export function useNotifications() {
  const { toast } = useToast();
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>("default");
  
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    refetchInterval: 30000, // Check every 30 seconds
  });

  useEffect(() => {
    // Set initial permission state
    if ("Notification" in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      try {
        const permission = await Notification.requestPermission();
        setNotificationPermission(permission);
        
        if (permission === "granted") {
          toast({
            title: "✓ Notifications Enabled",
            description: "You'll receive reminders 15 min before, 5 min before, and when tasks are due",
            duration: 4000,
          });
          hapticFeedback.success();
        } else if (permission === "denied") {
          toast({
            title: "Notifications Blocked",
            description: "Click the notification bell again for instructions to enable notifications",
            duration: 5000,
          });
        }
        
        return permission;
      } catch (error) {
        console.error("Error requesting notification permission:", error);
        toast({
          title: "Notification Error",
          description: "Unable to request notification permission",
          variant: "destructive",
          duration: 3000,
        });
      }
    } else {
      toast({
        title: "Notifications Not Supported",
        description: "Your browser doesn't support notifications",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  useEffect(() => {
    const checkDueTasks = () => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
      const currentDate = now.toISOString().split('T')[0];

      tasks.forEach((task) => {
        if (
          task.notificationsEnabled &&
          !task.completed &&
          task.date === currentDate &&
          task.time
        ) {
          // Check if task is due within the next 15 minutes
          const taskTime = new Date(`${task.date}T${task.time}`);
          const timeDiff = taskTime.getTime() - now.getTime();
          const minutesUntilDue = Math.floor(timeDiff / (1000 * 60));

          if (minutesUntilDue <= 15 && minutesUntilDue >= 14) {
            // Show notification 15 minutes before
            showTaskNotification(task, "15 minutes");
          } else if (minutesUntilDue <= 5 && minutesUntilDue >= 4) {
            // Show notification 5 minutes before
            showTaskNotification(task, "5 minutes");
          } else if (minutesUntilDue <= 0 && minutesUntilDue >= -1) {
            // Show notification when task is due
            showTaskNotification(task, "now");
          }
        }
      });
    };

    const interval = setInterval(checkDueTasks, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [tasks, toast]);

  const showTaskNotification = (task: Task, timeFrame: string) => {
    const message = timeFrame === "now" 
      ? `${task.title} is due now!`
      : `${task.title} is due in ${timeFrame}`;

    // Show toast notification
    toast({
      title: "Task Reminder",
      description: message,
      duration: 5000,
    });

    // Play notification sound and haptic feedback
    playNotificationSound();
    hapticFeedback.notification();

    // Show browser notification if permission granted
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("TaskFlow - Task Reminder", {
        body: message,
        icon: "/icon-192.png",
        badge: "/icon-192.png",
        tag: task.id, // Prevent duplicate notifications
        requireInteraction: timeFrame === "now",
      });
    }
  };

  return {
    notificationPermission,
    requestNotificationPermission,
    hasNotificationSupport: "Notification" in window,
  };
}
