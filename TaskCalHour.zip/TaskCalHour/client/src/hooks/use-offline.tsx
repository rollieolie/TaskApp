import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function useOffline() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const { toast } = useToast();

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast({
        title: "Connection restored",
        description: "You're back online. Syncing data...",
      });
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast({
        title: "No internet connection",
        description: "Working offline. Changes will sync when reconnected.",
        variant: "destructive",
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [toast]);

  return { isOnline };
}