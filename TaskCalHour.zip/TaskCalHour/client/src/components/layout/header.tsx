import { Button } from "@/components/ui/button";
import { useTheme } from "./theme-provider";
import { Moon, Sun, Bell, Plus, List, Calendar, Clock, BellOff } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import TaskForm from "@/components/tasks/task-form";
import { useNotifications } from "@/hooks/use-notifications";
import { hapticFeedback } from "@/lib/haptics";

export default function Header() {
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const [showTaskForm, setShowTaskForm] = useState(false);
  const { notificationPermission, requestNotificationPermission, hasNotificationSupport } = useNotifications();

  const navigation = [
    { name: "Tasks", href: "/tasks", icon: List },
    { name: "Calendar", href: "/calendar", icon: Calendar },
    { name: "Schedule", href: "/schedule", icon: Clock },
  ];

  const isActive = (href: string) => {
    if (href === "/tasks") {
      return location === "/" || location === "/tasks";
    }
    return location === href;
  };

  const handleNotificationClick = () => {
    hapticFeedback.light();
    
    if (notificationPermission === "default") {
      requestNotificationPermission();
    } else if (notificationPermission === "denied") {
      alert("Notifications are currently blocked.\n\nTo enable task reminders:\n1. Click the lock/info icon in your browser's address bar\n2. Set 'Notifications' to 'Allow'\n3. Refresh the page\n\nYou'll then receive reminders 15 minutes before, 5 minutes before, and when tasks are due.");
    } else if (notificationPermission === "granted") {
      alert("✓ Notifications are enabled!\n\nYou'll receive task reminders:\n• 15 minutes before due time\n• 5 minutes before due time\n• When the task is due\n\nReminders include sound and vibration on mobile devices.");
    }
  };

  const getNotificationIcon = () => {
    if (!hasNotificationSupport || notificationPermission === "denied") {
      return <BellOff className="w-4 h-4" />;
    }
    return <Bell className="w-4 h-4" />;
  };

  const getNotificationBadge = () => {
    if (notificationPermission === "granted") {
      return null; // No badge when notifications are working
    }
    return (
      <Badge
        variant={notificationPermission === "denied" ? "destructive" : "secondary"}
        className="absolute -top-1 -right-1 w-3 h-3 p-0 text-xs"
      />
    );
  };

  return (
    <>
      <header className="bg-white dark:bg-gray-850 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <List className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900 dark:text-white">
                TaskFlow
              </span>
            </Link>

            {/* Navigation Tabs - Desktop */}
            <nav className="hidden md:flex space-x-8">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`px-3 py-2 text-sm font-medium border-b-2 transition-colors ${
                      isActive(item.href)
                        ? "text-primary border-primary"
                        : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 border-transparent"
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-2 inline" />
                    {item.name}
                  </Link>
                );
              })}
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-4">
              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="text-gray-600 dark:text-gray-300"
              >
                {theme === "light" ? (
                  <Moon className="w-4 h-4" />
                ) : (
                  <Sun className="w-4 h-4" />
                )}
              </Button>

              {/* Notifications */}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleNotificationClick}
                className="text-gray-600 dark:text-gray-300 relative"
                title={
                  notificationPermission === "granted" 
                    ? "Notifications enabled" 
                    : notificationPermission === "denied"
                    ? "Notifications blocked - click to enable"
                    : "Click to enable notifications"
                }
              >
                {getNotificationIcon()}
                {getNotificationBadge()}
              </Button>

              {/* Add Task Button */}
              <Button 
                onClick={() => setShowTaskForm(true)}
                className="mobile-button"
              >
                <Plus className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Add Task</span>
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden border-t border-gray-200 dark:border-gray-700">
            <nav className="flex">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`mobile-touch flex-1 py-3 text-sm font-medium text-center border-b-2 transition-colors ${
                      isActive(item.href)
                        ? "text-primary border-primary bg-primary/10"
                        : "text-gray-500 dark:text-gray-400 border-transparent active:bg-gray-100 dark:active:bg-gray-800"
                    }`}
                  >
                    <Icon className="w-5 h-5 block mx-auto mb-1" />
                    <span className="text-xs">{item.name}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      </header>

      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSuccess={() => setShowTaskForm(false)}
      />
    </>
  );
}
