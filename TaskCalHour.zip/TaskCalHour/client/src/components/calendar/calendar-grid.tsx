import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Task } from "@shared/schema";

interface CalendarGridProps {
  tasks: Task[];
  onDateSelect: (date: string) => void;
  selectedDate: string;
}

export default function CalendarGrid({ tasks, onDateSelect, selectedDate }: CalendarGridProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const today = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const goToToday = () => {
    setCurrentDate(new Date());
    onDateSelect(today.toISOString().split('T')[0]);
  };

  const getTasksForDate = (date: string) => {
    return tasks.filter(task => task.date === date);
  };

  const formatDateKey = (day: number) => {
    return `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const isToday = (day: number) => {
    return today.getDate() === day && 
           today.getMonth() === currentMonth && 
           today.getFullYear() === currentYear;
  };

  const isSelected = (day: number) => {
    const dateKey = formatDateKey(day);
    return selectedDate === dateKey;
  };

  const renderCalendarDays = () => {
    const days = [];
    
    // Previous month trailing days
    const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    const daysInPrevMonth = new Date(prevYear, prevMonth + 1, 0).getDate();
    
    for (let i = firstDayOfMonth - 1; i >= 0; i--) {
      const day = daysInPrevMonth - i;
      days.push(
        <div
          key={`prev-${day}`}
          className="calendar-day p-2 rounded-lg text-gray-400 dark:text-gray-600 cursor-pointer"
        >
          <div className="text-sm mb-1">{day}</div>
        </div>
      );
    }

    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
      const dateKey = formatDateKey(day);
      const dayTasks = getTasksForDate(dateKey);
      const isSelectedDay = isSelected(day);
      const isTodayDay = isToday(day);

      days.push(
        <div
          key={day}
          className={`calendar-day p-2 rounded-lg cursor-pointer transition-colors ${
            isSelectedDay
              ? "bg-primary text-white"
              : isTodayDay
              ? "bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-100"
              : "text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
          }`}
          onClick={() => onDateSelect(dateKey)}
        >
          <div className={`text-sm mb-1 ${isTodayDay ? 'font-semibold' : ''}`}>
            {day}
          </div>
          {dayTasks.length > 0 && (
            <div className="space-y-1">
              {dayTasks.slice(0, 3).map((task, index) => (
                <div
                  key={task.id}
                  className={`w-2 h-2 rounded-full ${
                    isSelectedDay ? "bg-white opacity-80" : ""
                  }`}
                  style={{
                    backgroundColor: isSelectedDay ? undefined : task.color
                  }}
                />
              ))}
              {dayTasks.length > 3 && (
                <div className="text-xs text-gray-500">+{dayTasks.length - 3}</div>
              )}
            </div>
          )}
        </div>
      );
    }

    // Next month leading days
    const remainingDays = 42 - days.length; // 6 rows * 7 days
    for (let day = 1; day <= remainingDays; day++) {
      days.push(
        <div
          key={`next-${day}`}
          className="calendar-day p-2 rounded-lg text-gray-400 dark:text-gray-600 cursor-pointer"
        >
          <div className="text-sm mb-1">{day}</div>
        </div>
      );
    }

    return days;
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Calendar
        </h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateMonth("prev")}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-lg font-medium text-gray-900 dark:text-white min-w-[140px] text-center">
              {monthNames[currentMonth]} {currentYear}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateMonth("next")}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={goToToday}
          >
            Today
          </Button>
        </div>
      </div>

      {/* Days of Week Header */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {dayNames.map(day => (
          <div key={day} className="p-3 text-sm font-medium text-gray-500 dark:text-gray-400 text-center">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1">
        {renderCalendarDays()}
      </div>
    </div>
  );
}
