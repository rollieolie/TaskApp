import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, Bell } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { hapticFeedback } from "@/lib/haptics";
import { useToast } from "@/hooks/use-toast";
import TaskForm from "@/components/tasks/task-form";
import type { Task } from "@shared/schema";

interface TaskStatsProps {
  tasks: Task[];
}

export default function TaskStats({ tasks }: TaskStatsProps) {
  const today = new Date().toISOString().split('T')[0];
  const todayTasks = tasks.filter(task => task.date === today);
  
  const pending = todayTasks.filter(task => !task.completed).length;
  const completed = todayTasks.filter(task => task.completed).length;
  const overdue = tasks.filter(task => {
    const taskDate = new Date(task.date);
    const now = new Date();
    return taskDate < now && !task.completed;
  }).length;
  
  const total = todayTasks.length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  const [showTaskForm, setShowTaskForm] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleAddTask = () => {
    hapticFeedback.light();
    setShowTaskForm(true);
  };

  const handleScheduleEvent = () => {
    hapticFeedback.light();
    setLocation("/calendar");
    toast({
      title: "Calendar View",
      description: "Navigate to calendar to view and schedule events by date",
      duration: 3000,
    });
  };

  const handleSetReminder = () => {
    hapticFeedback.light();
    setLocation("/schedule");
    toast({
      title: "Daily Schedule",
      description: "Navigate to schedule to view and manage tasks by time",
      duration: 3000,
    });
  };

  return (
    <div className="space-y-6">
      {/* Today's Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Today's Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Pending Tasks
                </span>
              </div>
              <span className="font-semibold text-gray-900 dark:text-white">
                {pending}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Completed
                </span>
              </div>
              <span className="font-semibold text-gray-900 dark:text-white">
                {completed}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Overdue
                </span>
              </div>
              <span className="font-semibold text-gray-900 dark:text-white">
                {overdue}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button
            variant="ghost"
            className="w-full justify-start mobile-touch"
            onClick={handleAddTask}
          >
            <Plus className="w-4 h-4 mr-3 text-primary" />
            Add New Task
          </Button>
          <Button 
            variant="ghost" 
            className="w-full justify-start mobile-touch"
            onClick={handleScheduleEvent}
          >
            <Calendar className="w-4 h-4 mr-3 text-green-500" />
            View Calendar
          </Button>
          <Button 
            variant="ghost" 
            className="w-full justify-start mobile-touch"
            onClick={handleSetReminder}
          >
            <Bell className="w-4 h-4 mr-3 text-yellow-500" />
            Daily Schedule
          </Button>
        </CardContent>
      </Card>

      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSuccess={() => setShowTaskForm(false)}
      />
    </div>
  );
}
