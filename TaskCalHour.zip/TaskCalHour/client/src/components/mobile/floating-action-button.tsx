import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import TaskForm from "@/components/tasks/task-form";
import { hapticFeedback } from "@/lib/haptics";

export default function FloatingActionButton() {
  const [showTaskForm, setShowTaskForm] = useState(false);

  const handleClick = () => {
    hapticFeedback.light();
    setShowTaskForm(true);
  };

  return (
    <>
      <Button
        onClick={handleClick}
        className="fixed bottom-20 right-6 z-40 w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 bg-primary hover:bg-primary/90 md:hidden"
        size="icon"
      >
        <Plus className="w-6 h-6 text-white" />
      </Button>

      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSuccess={() => setShowTaskForm(false)}
      />
    </>
  );
}