import type { Task } from "@shared/schema";

interface TimeSlotProps {
  hour: number;
  tasks: Task[];
}

export default function TimeSlot({ hour, tasks }: TimeSlotProps) {
  const formatHour = (hour: number) => {
    if (hour === 0) return "12:00 AM";
    if (hour === 12) return "12:00 PM";
    if (hour < 12) return `${hour}:00 AM`;
    return `${hour - 12}:00 PM`;
  };

  const getTasksForHour = () => {
    return tasks.filter(task => {
      if (!task.time) return false;
      const taskHour = parseInt(task.time.split(':')[0]);
      return taskHour === hour;
    });
  };

  const hourTasks = getTasksForHour();

  const getPriorityBorderColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-red-500";
      case "medium":
        return "border-blue-500";
      case "low":
        return "border-green-500";
      default:
        return "border-gray-500";
    }
  };

  const getPriorityBgColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 dark:bg-red-900";
      case "medium":
        return "bg-blue-100 dark:bg-blue-900";
      case "low":
        return "bg-green-100 dark:bg-green-900";
      default:
        return "bg-gray-100 dark:bg-gray-800";
    }
  };

  const getPriorityTextColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-900 dark:text-red-100";
      case "medium":
        return "text-blue-900 dark:text-blue-100";
      case "low":
        return "text-green-900 dark:text-green-100";
      default:
        return "text-gray-900 dark:text-gray-100";
    }
  };

  return (
    <div className="time-slot flex border-b border-gray-200 dark:border-gray-700">
      <div className="w-20 py-4 text-sm text-gray-500 dark:text-gray-400 font-medium">
        {formatHour(hour)}
      </div>
      <div className="flex-1 py-4 pl-4">
        {hourTasks.length > 0 ? (
          <div className="space-y-2">
            {hourTasks.map((task) => (
              <div
                key={task.id}
                className={`rounded-lg p-3 mr-4 border-l-4 ${getPriorityBgColor(task.priority)} ${getPriorityBorderColor(task.priority)}`}
                style={{ borderLeftColor: task.color }}
              >
                <div className={`font-medium ${getPriorityTextColor(task.priority)}`}>
                  {task.title}
                </div>
                <div className={`text-sm ${getPriorityTextColor(task.priority)} opacity-80`}>
                  {task.time} {task.priority === "high" && "• High Priority"}
                </div>
                {task.description && (
                  <div className={`text-xs ${getPriorityTextColor(task.priority)} opacity-70 mt-1`}>
                    {task.description}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full"></div>
        )}
      </div>
    </div>
  );
}
