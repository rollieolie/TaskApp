// Local storage utilities for offline functionality
import type { Task } from "@shared/schema";

const STORAGE_KEYS = {
  TASKS: 'taskflow_tasks',
  THEME: 'taskflow_theme',
  SETTINGS: 'taskflow_settings',
} as const;

export interface StorageSettings {
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  defaultReminders: number; // minutes before task
}

export const storage = {
  // Task operations
  getTasks(): Task[] {
    try {
      const tasks = localStorage.getItem(STORAGE_KEYS.TASKS);
      return tasks ? JSON.parse(tasks) : [];
    } catch (error) {
      console.error('Failed to get tasks from localStorage:', error);
      return [];
    }
  },

  setTasks(tasks: Task[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch (error) {
      console.error('Failed to save tasks to localStorage:', error);
    }
  },

  addTask(task: Task): void {
    const tasks = this.getTasks();
    tasks.push(task);
    this.setTasks(tasks);
  },

  updateTask(taskId: string, updates: Partial<Task>): void {
    const tasks = this.getTasks();
    const index = tasks.findIndex(task => task.id === taskId);
    if (index !== -1) {
      tasks[index] = { ...tasks[index], ...updates };
      this.setTasks(tasks);
    }
  },

  deleteTask(taskId: string): void {
    const tasks = this.getTasks();
    const filteredTasks = tasks.filter(task => task.id !== taskId);
    this.setTasks(filteredTasks);
  },

  // Settings operations
  getSettings(): StorageSettings {
    try {
      const settings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return settings ? JSON.parse(settings) : {
        notificationsEnabled: true,
        soundEnabled: true,
        defaultReminders: 15,
      };
    } catch (error) {
      console.error('Failed to get settings from localStorage:', error);
      return {
        notificationsEnabled: true,
        soundEnabled: true,
        defaultReminders: 15,
      };
    }
  },

  setSettings(settings: StorageSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (error) {
      console.error('Failed to save settings to localStorage:', error);
    }
  },

  // Theme operations
  getTheme(): string {
    return localStorage.getItem(STORAGE_KEYS.THEME) || 'light';
  },

  setTheme(theme: string): void {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  },

  // Utility functions
  clear(): void {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  },

  export(): string {
    const data = {
      tasks: this.getTasks(),
      settings: this.getSettings(),
      theme: this.getTheme(),
      exportDate: new Date().toISOString(),
    };
    return JSON.stringify(data, null, 2);
  },

  import(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.tasks && Array.isArray(data.tasks)) {
        this.setTasks(data.tasks);
      }
      
      if (data.settings) {
        this.setSettings(data.settings);
      }
      
      if (data.theme) {
        this.setTheme(data.theme);
      }
      
      return true;
    } catch (error) {
      console.error('Failed to import data:', error);
      return false;
    }
  },
};
