// Haptic feedback utilities for mobile devices
export const hapticFeedback = {
  // Light feedback for button taps
  light: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate(10);
    }
  },

  // Medium feedback for interactions
  medium: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
  },

  // Heavy feedback for important actions
  heavy: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 30, 100]);
    }
  },

  // Success feedback
  success: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate([50, 50, 50]);
    }
  },

  // Error feedback
  error: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate([200, 100, 200]);
    }
  },

  // Notification feedback
  notification: () => {
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 50, 100, 50, 100]);
    }
  }
};

// Check if device supports haptic feedback
export const supportsHaptics = (): boolean => {
  return 'vibrate' in navigator;
};