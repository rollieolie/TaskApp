// Audio notification functionality
let audioContext: AudioContext | null = null;

export const playNotificationSound = async () => {
  try {
    // Create audio context if it doesn't exist
    if (!audioContext) {
      audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }

    // Resume audio context if suspended (required for user interaction)
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    // Create a simple notification beep
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Configure the beep sound
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime); // 800 Hz tone
    oscillator.type = 'sine';

    // Create an envelope for the sound
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

    // Play the sound
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);

  } catch (error) {
    console.warn('Failed to play notification sound:', error);
    
    // Fallback: try to use a simple beep
    try {
      // This won't work in all browsers but is a simple fallback
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmsgBzuL1fPReykGJn/L8t+NOwkSYrju6Zk=' );
      audio.play().catch(() => {
        // Silent fail if audio can't play
      });
    } catch (fallbackError) {
      // Silent fail for fallback too
    }
  }
};

// Initialize audio context on user interaction
export const initializeAudio = () => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
};

// Clean up audio context
export const cleanupAudio = () => {
  if (audioContext && audioContext.state !== 'closed') {
    audioContext.close();
    audioContext = null;
  }
};
