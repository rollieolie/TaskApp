import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/layout/theme-provider";
import Header from "@/components/layout/header";
import TasksPage from "@/pages/tasks";
import CalendarPage from "@/pages/calendar";
import SchedulePage from "@/pages/schedule";
import NotFound from "@/pages/not-found";
import { useNotifications } from "@/hooks/use-notifications";
import { useOffline } from "@/hooks/use-offline";
import InstallBanner from "@/components/pwa/install-banner";
import MobileStatusBar from "@/components/mobile/mobile-status-bar";
import FloatingActionButton from "@/components/mobile/floating-action-button";

function Router() {
  const notifications = useNotifications();
  useOffline();
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <MobileStatusBar />
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-20">
        <Switch>
          <Route path="/" component={TasksPage} />
          <Route path="/tasks" component={TasksPage} />
          <Route path="/calendar" component={CalendarPage} />
          <Route path="/schedule" component={SchedulePage} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <FloatingActionButton />
      <InstallBanner />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
