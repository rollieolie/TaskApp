import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import CalendarGrid from "@/components/calendar/calendar-grid";
import TaskItem from "@/components/tasks/task-item";
import TaskForm from "@/components/tasks/task-form";
import { hapticFeedback } from "@/lib/haptics";
import type { Task } from "@shared/schema";

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [showTaskForm, setShowTaskForm] = useState(false);

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const selectedDateTasks = tasks.filter(task => task.date === selectedDate);

  const formatSelectedDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600 dark:text-gray-400">Loading calendar...</div>
      </div>
    );
  }

  return (
    <div className="fade-in space-y-6">
      {/* Calendar */}
      <Card>
        <CardContent className="p-6">
          <CalendarGrid
            tasks={tasks}
            onDateSelect={setSelectedDate}
            selectedDate={selectedDate}
          />
        </CardContent>
      </Card>

      {/* Selected Day Details */}
      <Card>
        <CardHeader>
          <CardTitle>
            Tasks for {formatSelectedDate(selectedDate)}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {selectedDateTasks.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-500 dark:text-gray-400">
                No tasks scheduled for this date.
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {selectedDateTasks.map((task) => (
                <TaskItem key={task.id} task={task} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Floating Action Button */}
      <Button
        size="lg"
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg mobile-touch z-50"
        onClick={() => {
          hapticFeedback.light();
          setShowTaskForm(true);
        }}
      >
        <Plus className="h-6 w-6" />
      </Button>

      {/* Task Form with selected date pre-filled */}
      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSuccess={() => setShowTaskForm(false)}
        defaultValues={{
          date: selectedDate,
          time: "09:00",
          priority: "medium",
          color: "#10B981" // green for calendar events
        }}
      />
    </div>
  );
}
