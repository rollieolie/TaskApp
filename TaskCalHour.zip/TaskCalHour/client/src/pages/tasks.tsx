import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import TaskItem from "@/components/tasks/task-item";
import TaskStats from "@/components/tasks/task-stats";
import { useState } from "react";
import type { Task } from "@shared/schema";

type TaskFilter = "all" | "pending" | "completed" | "overdue";

export default function TasksPage() {
  const [filter, setFilter] = useState<TaskFilter>("all");

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const getFilteredTasks = () => {
    const now = new Date();
    
    switch (filter) {
      case "pending":
        return tasks.filter(task => !task.completed);
      case "completed":
        return tasks.filter(task => task.completed);
      case "overdue":
        return tasks.filter(task => {
          const taskDate = new Date(task.date);
          return taskDate < now && !task.completed;
        });
      default:
        return tasks;
    }
  };

  const filteredTasks = getFilteredTasks();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600 dark:text-gray-400">Loading tasks...</div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Task List */}
        <div className="flex-1">
          <Card>
            {/* Task List Header */}
            <CardHeader className="border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  My Tasks
                </h2>
                <div className="flex items-center space-x-2">
                  <Select value={filter} onValueChange={(value: TaskFilter) => setFilter(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tasks</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>

            {/* Task Items */}
            <CardContent className="p-6">
              {filteredTasks.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-500 dark:text-gray-400">
                    {filter === "all" ? "No tasks yet. Create your first task!" : `No ${filter} tasks.`}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTasks.map((task) => (
                    <TaskItem key={task.id} task={task} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Stats Sidebar */}
        <div className="lg:w-80">
          <TaskStats tasks={tasks} />
        </div>
      </div>
    </div>
  );
}
