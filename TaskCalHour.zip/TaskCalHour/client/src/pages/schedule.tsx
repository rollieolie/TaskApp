import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus } from "lucide-react";
import TimeSlot from "@/components/schedule/time-slot";
import TaskForm from "@/components/tasks/task-form";
import { hapticFeedback } from "@/lib/haptics";
import type { Task } from "@shared/schema";

export default function SchedulePage() {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [showTaskForm, setShowTaskForm] = useState(false);

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const dayTasks = tasks.filter(task => task.date === selectedDate);

  const goToToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  // Generate 24 hour slots (0-23)
  const timeSlots = Array.from({ length: 24 }, (_, i) => i);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600 dark:text-gray-400">Loading schedule...</div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <Card>
        {/* Schedule Header */}
        <CardHeader className="border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <CardTitle>Daily Schedule</CardTitle>
            <div className="flex items-center space-x-4">
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-auto"
              />
              <Button variant="outline" size="sm" onClick={goToToday}>
                Today
              </Button>
            </div>
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {formatDate(selectedDate)}
          </div>
        </CardHeader>

        {/* Time Slots */}
        <CardContent className="p-6">
          <div className="space-y-0">
            {timeSlots.map((hour) => (
              <TimeSlot
                key={hour}
                hour={hour}
                tasks={dayTasks.filter(task => {
                  if (!task.time) return false;
                  const taskHour = parseInt(task.time.split(':')[0]);
                  return taskHour === hour;
                })}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Floating Action Button */}
      <Button
        size="lg"
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg mobile-touch z-50"
        onClick={() => {
          hapticFeedback.light();
          setShowTaskForm(true);
        }}
      >
        <Plus className="h-6 w-6" />
      </Button>

      {/* Task Form with selected date and smart time pre-filled */}
      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSuccess={() => setShowTaskForm(false)}
        defaultValues={{
          date: selectedDate,
          time: (() => {
            const now = new Date();
            const nextHour = now.getHours() + 1;
            return `${nextHour.toString().padStart(2, '0')}:00`;
          })(),
          priority: "high",
          color: "#F59E0B", // yellow for schedule reminders
          notificationsEnabled: true
        }}
      />
    </div>
  );
}
