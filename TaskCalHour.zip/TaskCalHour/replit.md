# TaskFlow Mobile App

## Overview

TaskFlow is a Progressive Web App (PWA) for comprehensive task management, built with React frontend and Express.js backend. The application provides task management with calendar views, daily scheduling, and mobile-first notifications. Features offline functionality, haptic feedback, and can be installed as a native mobile app on phones and tablets. Uses PostgreSQL database with Drizzle ORM for persistent data storage and shadcn/ui components for responsive mobile design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a monolithic full-stack architecture with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

### Deployment Strategy
The application is configured for Replit deployment with:
- Development server using tsx for hot reloading
- Production build using Vite for frontend and esbuild for backend
- Unified start script for production deployment

## Key Components

### Frontend Architecture (Mobile PWA)
- **Component Library**: shadcn/ui components built on Radix UI primitives with mobile-first design
- **Theme System**: Dark/light theme support with CSS variables and mobile adaptations
- **State Management**: TanStack Query for API state, React hooks for local state
- **Routing**: File-based page structure with wouter routing optimized for mobile navigation
- **Notifications**: Toast notifications, browser notifications, haptic feedback, and audio alerts
- **PWA Features**: Service worker for offline functionality, app installation prompts, and mobile status indicators
- **Touch Interactions**: Haptic feedback for button presses, task completion, and notifications

### Backend Architecture
- **API Layer**: RESTful Express.js endpoints for task management
- **Data Layer**: Drizzle ORM with PostgreSQL for persistent data storage
- **Storage Interface**: DatabaseStorage class implementing IStorage interface
- **Database Connection**: Neon serverless PostgreSQL with connection pooling
- **Middleware**: Request logging, error handling, and JSON parsing

### Database Schema
The application uses a single `tasks` table with the following structure:
- Task identification (UUID primary key)
- Task details (title, description, date, time)
- Task properties (priority, color, completion status)
- Notification settings
- Timestamps for creation tracking

## Data Flow

### Task Management Flow
1. **Task Creation**: Frontend form → API validation → Database insertion → UI update
2. **Task Retrieval**: Component mount → TanStack Query → API request → Database query → UI render
3. **Task Updates**: User interaction → Optimistic update → API request → Database update → Cache invalidation
4. **Task Deletion**: User confirmation → API request → Database deletion → UI refresh

### Notification Flow
1. **Periodic Check**: Frontend polls tasks every 30 seconds
2. **Due Date Calculation**: Compares current time with task deadlines
3. **Notification Trigger**: Browser notification + sound + toast for approaching deadlines
4. **User Interaction**: Notification permission management and sound controls

### Real-time Updates
The application uses polling-based updates with TanStack Query's refetch intervals for near real-time task synchronization.

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Router (wouter)
- **State Management**: TanStack Query for server state
- **Form Management**: React Hook Form with Zod validation
- **UI Components**: Radix UI primitives, shadcn/ui components
- **Styling**: Tailwind CSS, class-variance-authority for component variants

### Backend Dependencies
- **Server Framework**: Express.js with TypeScript support
- **Database**: Drizzle ORM with PostgreSQL driver (@neondatabase/serverless)
- **Validation**: Zod for schema validation
- **Development**: tsx for TypeScript execution, esbuild for production builds

### Development Tools
- **Build Tools**: Vite for frontend, esbuild for backend
- **TypeScript**: Full TypeScript support across the stack
- **Database Tools**: Drizzle Kit for schema migrations and database management

## Deployment Strategy

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **Development**: Hot reloading with Vite dev server and tsx
- **Production**: Static file serving with Express.js

### Build Process
1. **Frontend Build**: Vite compiles React app to static files
2. **Backend Build**: esbuild bundles Express server to single file
3. **Asset Management**: Static files served from Express in production
4. **Database Migration**: Drizzle migrations managed separately

### Replit Integration
The application includes Replit-specific configurations:
- Development banner for external access
- Cartographer plugin for debugging
- Runtime error overlay for development
- Replit-optimized Vite configuration

The architecture prioritizes developer experience with hot reloading, type safety, and clear separation of concerns while maintaining simplicity for deployment and scaling.

## Recent Changes

### July 31, 2025 - Quick Actions Enhancement
- **Navigation Fixed**: Quick Actions now properly navigate to appropriate pages instead of all opening task forms
- **Page-Specific Features**: Added floating action buttons on Calendar and Schedule pages for context-aware task creation
- **Smart Defaults**: Calendar page pre-fills events with selected date and green color, Schedule page pre-fills reminders with smart time calculations
- **User Experience**: Each Quick Action now provides distinct functionality - Add Task (task form), View Calendar (calendar navigation), Daily Schedule (schedule navigation)

### July 31, 2025 - Database Integration
- **Database Added**: Integrated PostgreSQL database for persistent data storage
- **Storage Migration**: Migrated from MemStorage to DatabaseStorage implementation
- **Schema Implementation**: Tasks table with UUID primary keys, timestamps, and full task properties
- **Database Connection**: Configured Neon serverless PostgreSQL with proper environment variables
- **API Testing**: Verified all CRUD operations working correctly with database persistence